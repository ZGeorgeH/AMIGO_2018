A=dir('Auto*.m');
B=dir('Read*.m');
