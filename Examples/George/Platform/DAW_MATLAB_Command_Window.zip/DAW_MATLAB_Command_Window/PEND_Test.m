Write_Target_Position(40000,1);
Write_Target_Position(10000,1);
read(Controllers,'coils',269,1,1) % read position compelete status from all axis  