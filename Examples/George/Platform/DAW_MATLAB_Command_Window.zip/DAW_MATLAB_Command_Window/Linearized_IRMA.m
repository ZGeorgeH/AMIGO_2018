function dy_dt=Linearized_IRMA(t,y,u)
    dy_dt=0.0467/667.62*u-y/667.62;
end