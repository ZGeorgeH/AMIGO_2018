% Parameters for IRMA
load K;
load y0gal;
y_init=y0;
y0_for_Sim=y0;

% Experiment start
Experiment_Length=2000; % min

% Load reference ouput r
% Control output y from t=1~1000min
% Specified output is r
r(1:300)=1; r(301:600)=0.8; r(601:3120)=0.8; 
%r(1:500)=linspace(1,1,500); r(501:1500)=linspace(1,0.2,1000); 
%r(1:1000)=linspace(0.2,1,1000); r(1001:2000)=linspace(1,0.2,1000); 

% PWM
PWM_Time=0:Experiment_Length-1;
PWM_Ref=0.5*sawtooth(2*pi/10*PWM_Time)+0.5;

% Set parameters
Normalize_Factor_Segmentation = 0.046735005043180;
Normalize_Factor_IRMA         = 0.046735005043180;
% Pre allocation for speed
Normalized_Fluo_Out=zeros(1,Experiment_Length);
Error=zeros(1,Experiment_Length);
Integration=zeros(1,Experiment_Length);
Controller_Out=zeros(1,Experiment_Length);
u=zeros(1,Experiment_Length);
yhat_out=zeros(1,Experiment_Length+1);
ys=zeros(1,Experiment_Length+1);
ys(1)=y0(1);
%ys(1)=y_init;
yhat_out_delayed=zeros(1,Experiment_Length+146);
yhat_out_delayed(1:101)=y0(1);
ysimout=zeros(1,Experiment_Length+1);
ysimout(1)=y0(1);
Fluorescence_Record=y0(1);
LP_out=zeros(1,Experiment_Length+1);
LP_out(1)=0;

% PI controller parameters
Kp=8.2; Ki=0.1028;
% Initialize the system timer
Last_Loop_Execution=clock;
Elapsed_Time=0;
for Time=1:Experiment_Length
    % Check for New files and segment to give fluorescence output
     %ExistNewFile=NewFile_Detect_and_Segment(Auto_Detect_Directory,Mask);
    % Testing purpose
    if rem(Time,5)==0
        Fluorescence_Record=ysimout(Time);
    end
    % Normalization 
    Normalized_Fluo_Out(Time)=Fluorescence_Record/Normalize_Factor_Segmentation;
    
    %% Compute error
    Error(Time)=r(Time)-ys(Time);   
     
    %%
    % PI controller
    if Time==1
        Integration(Time)=1;
    else
        % Limited integral anti wind-up
        if     Controller_Out(Time-1)>=1 && ((Error(Time)+Error(Time-1)) > 0)
            Integration(Time)=Integration(Time-1);
        elseif Controller_Out(Time-1)<=0 && ((Error(Time)+Error(Time-1)) < 0)
            Integration(Time)=Integration(Time-1); 
        else
            Integration(Time)=Integration(Time-1)+Ki*(Error(Time)+Error(Time-1))/2;
        end
    end
    Controller_Out(Time)=Kp*Error(Time)+Integration(Time);

    %% PWM
    if Controller_Out(Time) > PWM_Ref(Time)
        u(Time)=1;
    else
        u(Time)=0;
    end
    
    
    %% Estimation with IRMA model
    yhat=dde23(@(t,sol,Z) IRMA5b(t,sol,Z,K,u(Time),0,t), 1 ,y_init,[Time Time+1]);
    y_init=yhat;
    yhat_out(Time+1)=yhat.y(1,end); 
    
    
    % Generate a delayed version
    yhat_out_delayed(Time+100)=yhat_out(Time);
    
    % Compare actual output y with delayed model output
    y_actual=Normalized_Fluo_Out(Time)*Normalize_Factor_IRMA;
    
    % Low pass filter
    %LP_in(Time)=y_actual-yhat_out_delayed(Time);
    LP_out(Time+1)=(19/20)*LP_out(Time)+1/20*(y_actual-yhat_out_delayed(Time));
    
    ys(Time+1)=(yhat_out(Time+1)+LP_out(Time))/Normalize_Factor_IRMA;
    %ys(Time+1)=(yhat_out(Time+1))/Normalize_Factor_IRMA;
    %% Send input to actuators
    
    Gal_Axis=1;
    Glu_Axis=2;
    if (u(Time)==1)
        Write_Target_Position(80000,1);
        Write_Target_Position(0,2);
    else
        Write_Target_Position(0,1);
        Write_Target_Position(80000,2);        
    end
    
    %% Use IRMA model to simuate
    Forward_Sim = dde23(@(t,sol,Z) IRMA5b(t,sol,Z,K,u(Time),0,t), 100 ,y0_for_Sim,[Time Time+1]);
    y0_for_Sim=Forward_Sim;
    ysimout(Time+1)=Forward_Sim.y(1,end);    
    %% Some loop to insure the Experiment "Time" loop runs every 1min
    fprintf('Experiment Time = %d min\n',Time);
    
    while(Elapsed_Time<20)
        Current_Loop_Execution=clock;
        Elapsed_Time=etime(Current_Loop_Execution,Last_Loop_Execution);
        pause(2);
        disp('waiting...')
    end
    Last_Loop_Execution=Current_Loop_Execution;
    Elapsed_Time=0;
    
end
ysimout_Normalized=ysimout/Normalize_Factor_IRMA;

plot(r);
hold on;
%plot(ysimout_Normalized);
plot(Normalized_Fluo_Out);
%plot(Error);
%plot(Integration)
%plot(Controller_Out);
%plot(ys);
%plot(yhat_out/Normalize_Factor_IRMA);
%plot(yhat_out_delayed/Normalize_Factor_IRMA);
%plot(LP_out/Normalize_Factor_IRMA);
%hold off;
axis([0 2000 0 1.2]);