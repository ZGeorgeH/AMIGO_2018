% for i=1:5
%     fprintf('Axis %d Home compelete!\n',i);
% end

HEND=[1,1,1,1,1];
if (all(HEND)==1)
    disp('hahaha');
end